export default function FAQ() {
  return (
    <div>
      <h2>FAQ</h2>
      <p>Miten vaihdan salasanan?</p>
    </div>
  );
}
