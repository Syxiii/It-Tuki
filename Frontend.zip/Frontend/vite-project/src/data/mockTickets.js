const mockTickets = [
  { id: 1, title: "Tulostin ei toimi", status: "Avoin" },
  { id: 2, title: "VPN-yhteys poikki", status: "Käsittelyssä" },
  { id: 3, title: "Sähköposti ei lähde", status: "Ratkaistu" }
];

export default mockTickets;
