const mockTickets = [
  { id: 1, title: "VPN ei toimi", description: "VPN ei yhdistä", status: "Avoin", user: "matti@example.com" },
  { id: 2, title: "Tulostin rikki", description: "Tulostin ei toimi", status: "Käsittelyssä", user: "matti@example.com" },
  { id: 3, title: "Sähköposti ei toimi", description: "En saa sähköpostia", status: "Ratkaistu", user: "anna@example.com" }
];

export default mockTickets;
